jQuery( document ).ready(function($) {
    $('select.iworks-select2').select2();
});
